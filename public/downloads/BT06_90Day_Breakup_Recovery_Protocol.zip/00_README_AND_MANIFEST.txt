======================================================================
bootey(R) DIGITAL TOOLKIT ARCHIVE
Product Code: BT — 06
Title: The 90-Day Breakup Recovery Protocol
Subtitle: Healing journal & toolkit · PDF, Notion
Price: $9.99 USD
Archive: BT06_90Day_Breakup_Recovery_Protocol.zip
Generated for: Verified Customer
======================================================================

PRODUCT SUMMARY:
Ninety daily micro-interventions, structured no-contact tracking, and identity-rebuild exercises — designed for the first ninety days after a breakup, when good advice is everywhere and an actual plan is nowhere.

TABLE OF CONTENTS / MODULES:
  [1] 01 / The Dopamine Withdrawal Timeline (Days 1–14)
  [2] 02 / The No-Contact Fortress Protocol & Urge Surfing
  [3] 03 / Cognitive Disentanglement & Unsent Letters (Days 15–60)
  [4] 04 / Rebuilding the Self: Solo Anchor Habits (Days 61–90)

INCLUDED ASSET MANIFEST (16 files):
  1. 00-START-HERE/Start-Here-Guide.pdf (1.8 MB) - Day 1 triage: Emergency nervous system regulation and no-contact boundaries.
  2. 01-STARTER-The-First-72-Hours/The-First-72-Hours-Emergency-Triage.pdf (3.4 MB) - The acute 72-hour survival roadmap: What to do and not do immediately.
  3. 02-CORE-90-Day-Protocol-and-Journal/The-90-Day-Breakup-Recovery-Protocol.pdf (12.6 MB) - Comprehensive 90-day day-by-day healing journal and somatic recovery guide.
  4. 03-CORE-COMANION-No-Contact-Tracker/No-Contact-Tracker.pdf (2.4 MB) - Daily impulse interceptor, urges log, and no-contact streak counter.
  5. 04-PREMIUM-Weekly-Check-In-Templates/Weekly-Check-In-Templates.pdf (3.1 MB) - 12-week structured reflection, detachment metrics, and self-worth audits.
  6. 05-PREMIUM-Community-Launch-Playbook/Community-Launch-Playbook.pdf (2.2 MB) - Support system activation, accountability partner setup, and recovery circles.
  7. 06-PREMIUM-Onboarding-Email-Sequence/Onboarding-Email-Sequence.pdf (1.9 MB) - 14-day automated breakup recovery drip lessons and cognitive reframes.
  8. 07-LEGAL-Disclaimer-and-Safety-Notice/Disclaimer-and-Safety-Notice.pdf (650 KB) - Mental health safety guidelines, emergency hotline contacts, and disclaimer.
  9. 08-NOTION-IMPORT-PACK/90-Day-Protocol-Database.csv (180 KB) - Complete 90-day protocol database ready for 1-click Notion import.
  10. 08-NOTION-IMPORT-PACK/Daily-Page-Template.md (24 KB) - Notion daily journaling template with somatic and gratitude prompts.
  11. 08-NOTION-IMPORT-PACK/Weekly-Check-In-Template.md (18 KB) - Weekly check-in reflection template for Notion workspace.
  12. 08-NOTION-IMPORT-PACK/README-Import-Guide.md (12 KB) - Step-by-step 1-click Notion import instructions and database setup.
  13. 09-EDITABLE-HTML-SOURCES/core.html (480 KB) - Editable source file for the core 90-day recovery protocol.
  14. 09-EDITABLE-HTML-SOURCES/tracker.html (240 KB) - Editable source file for the no-contact tracker and habit grid.
  15. 09-EDITABLE-HTML-SOURCES/checkins.html (210 KB) - Editable source file for weekly check-in worksheets.
  16. README.txt (16 KB) - Master recovery protocol roadmap and asset orientation.

LICENSING & USAGE:
This toolkit is protected by copyright and licensed under the bootey Single-Seat Lifetime Commercial License.
You may use, adapt, and implement all worksheets, spreadsheets, and guides for personal and business use.
Redistribution, reselling, or public uploading of raw files is prohibited.

SUPPORT & POLAR CHECKOUT FULFILLMENT:
For inquiries or licensing questions: support@bootey.com
https://bootey.com
