======================================================================
bootey(R) DIGITAL TOOLKIT ARCHIVE
Product Code: BT — 10
Title: Caregiver Burnout Recovery Kit
Subtitle: Self-care & resilience toolkit · PDF
Price: $19.99 USD
Archive: BT10_Caregiver_Burnout_Recovery_Kit.zip
Generated for: Verified Customer
======================================================================

PRODUCT SUMMARY:
A short orientation and actionable kit for the caregiver who has already tried generic self-care advice (like "take a bubble bath") and found it useless. Meet four practical tools: assess, break, ask, and hand off.

TABLE OF CONTENTS / MODULES:
  [1] 01 / Why Standard Self-Care Advice Fails Caregivers
  [2] 02 / The Four Tools: Assess, Break, Ask, and Hand Off
  [3] 03 / Your First 24 Hours: Three Five-Minute Tactical Actions
  [4] 04 / How to Print, Annotate, and Reuse Every Worksheet

INCLUDED ASSET MANIFEST (10 files):
  1. README.txt (18 KB) - Caregiver orientation, quick-start guide, and 4-tool practical methodology.
  2. 01-Start-Here-Guide/Module-01-Start-Here-Guide.pdf (3.8 MB) - Module 01: Immediate triage & the 24-hour caregiver survival protocol.
  3. 02-Burnout-Self-Assessment/Module-02-Burnout-Self-Assessment.pdf (2.4 MB) - Module 02: Compassion fatigue, secondary trauma, and burnout self-assessment test.
  4. 03-Micro-Break-Protocol/Module-03-Micro-Break-Protocol.pdf (2.1 MB) - Module 03: 5-minute somatic micro-breaks and nervous system regulation.
  5. 04-Help-Request-Scripts/Module-04-Help-Request-Scripts.pdf (1.9 MB) - Module 04: Word-for-word scripts to ask family and friends for specific help without guilt.
  6. 05-Respite-Care-Decision-Framework/Module-05-Respite-Care-Decision-Framework.pdf (2.6 MB) - Module 05: In-home vs adult day vs facility respite decision trees and subsidy funding.
  7. 06-Sibling-Help-Request-Letter-Pack/Module-06-Sibling-Help-Request-Letter-Pack.pdf (2.0 MB) - Module 06: Non-confrontational boundary and task allocation letters for estranged siblings.
  8. 07-Quick-Reference-Cards/Module-07-Quick-Reference-Cards.pdf (1.8 MB) - Module 07: Printable pocket cards for acute overload and emergency de-escalation.
  9. 08-Crisis-Resources-and-Escalation-Guide/Module-08-Crisis-Resources-and-Escalation-Guide.pdf (2.0 MB) - Module 08: 24/7 hotlines, APS contacts, legal medical authority, and emergency escalation.
  10. LICENSE_PERPETUAL.txt (12 KB) - bootey Single-Seat Lifetime Commercial Perpetual License.

LICENSING & USAGE:
This toolkit is protected by copyright and licensed under the bootey Single-Seat Lifetime Commercial License.
You may use, adapt, and implement all worksheets, spreadsheets, and guides for personal and business use.
Redistribution, reselling, or public uploading of raw files is prohibited.

SUPPORT & POLAR CHECKOUT FULFILLMENT:
For inquiries or licensing questions: support@bootey.com
https://bootey.com
