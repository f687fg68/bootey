# README.txt
Toolkit: BT — 03 - Medical Symptom War Book
Asset: Orientation, quick-start guide, and medical record preparation tips.

============================================================
Official template and operational content ready for deployment.
