======================================================================
bootey(R) DIGITAL TOOLKIT ARCHIVE
Product Code: BT — 05
Title: Postpartum Identity Rebuild Planner
Subtitle: Postpartum wellness · PDF bundle
Price: $29.99 USD
Archive: BT05_Postpartum_Identity_Rebuild.zip
Generated for: Verified Customer
======================================================================

PRODUCT SUMMARY:
A guided journal and strategic framework for the woman you were, the mother you are becoming, and the self waiting on the other side of this seismic transformation. Reconnect with autonomy, body neutrality, and career balance.

TABLE OF CONTENTS / MODULES:
  [1] 01 / Identity Reflection & The Biology of Matrescence
  [2] 02 / Grieving the Former Self Without Guilt
  [3] 03 / Rebuilding Intimacy and Partner Division of Labor
  [4] 04 / The Solo Anchor Habits: 15-Minute Daily Sanity Routines

INCLUDED ASSET MANIFEST (9 files):
  1. 01_Identity_Becoming.pdf (4.8 MB) - Matrescence identity reconstruction and emotional audit after child birth.
  2. 02_Body_Neutrality_Grief.pdf (4.2 MB) - Body neutrality exercises and physical postpartum transition journal.
  3. 03_Partner_Check_In.pdf (3.1 MB) - Invisible labor division, emotional check-in scripts, and relationship preservation.
  4. 04_Mental_Health_Tracker.pdf (3.5 MB) - Mood, sleep deprivation, hormonal fluctuation, and overwhelm tracking log.
  5. 05_Milestone_Recorder.pdf (2.4 MB) - Motherhood personal milestone and identity growth chronicle.
  6. 06_Boundary_Scripts.pdf (2.1 MB) - Word-for-word boundary setting scripts for in-laws, visitors, and advice.
  7. 07_SelfCare_ReturnToWork.pdf (2.6 MB) - Return-to-work transition roadmap and childcare emotional integration.
  8. 08_Reflection_Onboarding.pdf (1.8 MB) - 4th-trimester reflection prompts and onboarding manual.
  9. README.txt (14 KB) - Postpartum caregiver welcome orientation and self-compassion primer.

LICENSING & USAGE:
This toolkit is protected by copyright and licensed under the bootey Single-Seat Lifetime Commercial License.
You may use, adapt, and implement all worksheets, spreadsheets, and guides for personal and business use.
Redistribution, reselling, or public uploading of raw files is prohibited.

SUPPORT & POLAR CHECKOUT FULFILLMENT:
For inquiries or licensing questions: support@bootey.com
https://bootey.com
