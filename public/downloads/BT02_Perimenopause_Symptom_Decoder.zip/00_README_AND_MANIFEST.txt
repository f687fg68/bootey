======================================================================
bootey(R) DIGITAL TOOLKIT ARCHIVE
Product Code: BT — 02
Title: Perimenopause Symptom Decoder
Subtitle: Hormonal health tracker · PDF
Price: $14.99 USD
Archive: BT02_Perimenopause_Symptom_Decoder.zip
Generated for: Verified Customer
======================================================================

PRODUCT SUMMARY:
Your symptoms are real. Your hormones are shifting. This decoder maps 34 symptoms to five hormonal patterns — then hands you the action plans, food frameworks, and doctor-ready scripts that turn "you're too young for menopause" into a plan you can act on this week.

TABLE OF CONTENTS / MODULES:
  [1] 01 / The 34 Symptoms Clustered by Hormonal Pathway
  [2] 02 / Five Core Pattern Profiles (Estrogen Dominance to Exhaustion)
  [3] 03 / The 1-Page Action Plans for Sleep, Mood & Metabolism
  [4] 04 / The Doctor-Ready Script for Your Next Appointment

INCLUDED ASSET MANIFEST (3 files):
  1. The-Perimenopause-Symptom-Decoder.pdf (11.8 MB) - Comprehensive 38-page mapping manual & cluster guides.
  2. The-Perimenopause-Symptom-Decoder-source.html (2.4 MB) - Editable local HTML source file for the symptom mapping protocol.
  3. cover-preview.png (1.2 MB) - High-resolution design cover preview for the symptom decoder.

LICENSING & USAGE:
This toolkit is protected by copyright and licensed under the bootey Single-Seat Lifetime Commercial License.
You may use, adapt, and implement all worksheets, spreadsheets, and guides for personal and business use.
Redistribution, reselling, or public uploading of raw files is prohibited.

SUPPORT & POLAR CHECKOUT FULFILLMENT:
For inquiries or licensing questions: support@bootey.com
https://bootey.com
