======================================================================
bootey(R) DIGITAL TOOLKIT ARCHIVE
Product Code: BT — 20
Title: Craft Patterns Investor Package
Subtitle: Business pitch kit · DOCX, PPTX, XLSX
Price: $9.99 USD
Archive: BT20_Craft_Patterns_Investor_Package.zip
Generated for: Verified Customer
======================================================================

PRODUCT SUMMARY:
A warm, tactile, beautifully styled pitch deck and investor memo for creative studios, artisan goods, and craft businesses raising seed capital or small business loans.

TABLE OF CONTENTS / MODULES:
  [1] 01 / The Artisan Studio Pitch Deck (12 Slides)
  [2] 02 / Investor Executive Memorandum & Thesis Template
  [3] 03 / 3-Year Pro-Forma Cash Flow & Unit Economics Model
  [4] 04 / Cap Table & Debt Repayment Schedule

INCLUDED ASSET MANIFEST (6 files):
  1. 01_Business_Plan.docx (4.8 MB) - Complete 24-page studio business plan and executive summary.
  2. 02_Pitch_Deck.pptx (11.5 MB) - 14-slide tactile aesthetic presentation deck for creative businesses.
  3. 03_Sample_Pattern_Catalog.pdf (4.2 MB) - High-end artisan pattern collection sample with unit economics.
  4. 04_Financial_Model.xlsx (2.6 MB) - 3-year revenue, inventory turnover, and pro-forma margin model.
  5. 05_Marketing_Brief.pdf (1.4 MB) - Omnichannel D2C and wholesale distribution strategy.
  6. README.txt (14 KB) - Step-by-step guide to presenting to seed investors or banks.

LICENSING & USAGE:
This toolkit is protected by copyright and licensed under the bootey Single-Seat Lifetime Commercial License.
You may use, adapt, and implement all worksheets, spreadsheets, and guides for personal and business use.
Redistribution, reselling, or public uploading of raw files is prohibited.

SUPPORT & POLAR CHECKOUT FULFILLMENT:
For inquiries or licensing questions: support@bootey.com
https://bootey.com
