======================================================================
bootey(R) DIGITAL TOOLKIT ARCHIVE
Product Code: BT — 15
Title: Honest Numbers Pricing Kit
Subtitle: Product pricing framework · XLSX, PDF
Price: $19.99 USD
Archive: BT15_Honest_Numbers_Pricing_Kit.zip
Generated for: Verified Customer
======================================================================

PRODUCT SUMMARY:
True unit cost, the full fee stack, and a pricing ladder that pays you. Built for candles, jewelry, ceramics, stickers, knitwear, soap and goods sold on Etsy, at craft fairs, or through Shopify.

TABLE OF CONTENTS / MODULES:
  [1] 01 / Raw Material Costs Down to the Gram & Milliliter
  [2] 02 / Real Labor Hourly Valuation (Stop Working for $4/hr)
  [3] 03 / Marketplace Fee Stacks: Etsy, Stripe, Shopify, & Shipping
  [4] 04 / The 2.2x Wholesale vs 4x Retail Multiplication Ladder

INCLUDED ASSET MANIFEST (8 files):
  1. Honest-Numbers-Pricing-Kit.xlsx (6.2 MB) - Master unit cost, labor hour, and platform fee pricing model.
  2. Fair-Stand-Lite-Craft-Fair-Edition.xlsx (3.4 MB) - In-person market table, square fees, and booth fee breakeven calculator.
  3. Honest-Numbers-Quick-Start-Guide.pdf (3.1 MB) - The 4-step pricing formula (materials, labor, platform, profit).
  4. README-Start-Here.pdf (1.2 MB) - Orientation for Etsy, Shopify, and craft fair sellers.
  5. Quick-Win-Challenge-Worksheet.pdf (1.1 MB) - Find $300 in missed margin in under 30 minutes.
  6. Upgrade-Flyer-Etsy-Seller-Dashboard.pdf (850 KB) - Etsy fee increase defense & wholesale multiplication guide.
  7. sources/bundle_flyer.html (140 KB) - Printable price tags and product catalog templates.
  8. sources/guide_cover.html (95 KB) - Source layout for custom maker brand cards.

LICENSING & USAGE:
This toolkit is protected by copyright and licensed under the bootey Single-Seat Lifetime Commercial License.
You may use, adapt, and implement all worksheets, spreadsheets, and guides for personal and business use.
Redistribution, reselling, or public uploading of raw files is prohibited.

SUPPORT & POLAR CHECKOUT FULFILLMENT:
For inquiries or licensing questions: support@bootey.com
https://bootey.com
