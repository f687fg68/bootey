======================================================================
bootey(R) DIGITAL TOOLKIT ARCHIVE
Product Code: BT — 24
Title: Cancer Caregiver Command Center
Subtitle: Treatment & care coordinator · PDF
Price: $29.99 USD
Archive: BT24_Cancer_Caregiver_Command_Center.zip
Generated for: Verified Customer
======================================================================

PRODUCT SUMMARY:
A master coordination binder and private journal for the cancer caregiver. Track chemotherapy rounds, lab nadirs, symptom spikes, while preserving space for the caregiver's own mood, sleep, and emotional endurance.

TABLE OF CONTENTS / MODULES:
  [1] 01 / Treatment Staging & Oncologist Consultation Notes
  [2] 02 / Chemotherapy & Radiation Side Effect Mitigation Matrices
  [3] 03 / Emergency Symptom Triage & Red-Flag Call Lists
  [4] 04 / Caregiver Sanity & Self-Care Journal (25 Pages)

INCLUDED ASSET MANIFEST (8 files):
  1. 00_README_and_Legal_Disclaimer.pdf (1.2 MB) - Caregiver advocacy orientation and legal disclaimer.
  2. 01_Treatment_Appointment_Command_Log.pdf (6.4 MB) - Oncologist question builder and treatment visit notes.
  3. 02_Medication_and_Side_Effect_Tracker.pdf (5.8 MB) - Chemo/radiation dosing schedule and symptom spike log.
  4. 03_Caregiver_Sanity_and_Self_Care_Journal.pdf (6.5 MB) - 25-page decompression journal for guilt, sleep, and exhaustion.
  5. 04_Family_Communication_Hub.pdf (2.4 MB) - Update templates for family members to stop repetitive text messages.
  6. 05_Financial_and_Insurance_Tracker.pdf (3.2 MB) - Out-of-pocket, prior authorization, and copay assistance ledger.
  7. 06_End_of_Life_Conversation_Guide.pdf (1.9 MB) - Gentle, clear framework for advance directives and wishes.
  8. 07_Sibling_and_Helper_Coordination_Roster.pdf (1.0 MB) - Meal train, rides, and chore handoff coordination sheets.

LICENSING & USAGE:
This toolkit is protected by copyright and licensed under the bootey Single-Seat Lifetime Commercial License.
You may use, adapt, and implement all worksheets, spreadsheets, and guides for personal and business use.
Redistribution, reselling, or public uploading of raw files is prohibited.

SUPPORT & POLAR CHECKOUT FULFILLMENT:
For inquiries or licensing questions: support@bootey.com
https://bootey.com
