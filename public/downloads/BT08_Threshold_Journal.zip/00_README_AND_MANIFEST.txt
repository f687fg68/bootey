======================================================================
bootey(R) DIGITAL TOOLKIT ARCHIVE
Product Code: BT — 08
Title: Threshold Journal
Subtitle: Belief deconstruction guide · PDF
Price: $9.99 USD
Archive: BT08_Threshold_Journal.zip
Generated for: Verified Customer
======================================================================

PRODUCT SUMMARY:
A self-guided companion for adults re-examining a high-control religious or philosophical world. Ninety days of structured prompts across three phases — grounding, examination, and rebuilding — with the Threshold Framework and belief-audit method woven through.

TABLE OF CONTENTS / MODULES:
  [1] 01 / Phase One: Grounding & Emotional Safety
  [2] 02 / Phase Two: The Belief Audit (Deconstruction Without Despair)
  [3] 03 / Phase Three: The Rebuilding Matrix (Autonomous Values)
  [4] 04 / Navigating Estrangement & Family Boundaries

INCLUDED ASSET MANIFEST (19 files):
  1. 00_Start_Here_Quick-Start_Guide.pdf (1.8 MB) - Threshold Journal welcome & quick start guide.
  2. 01_Starter_Journal_The_First_30_Days.pdf (3.4 MB) - Phase 1: Grounding & emotional safety journal prompts.
  3. 02_The_90-Day_Deconstruction_Journal.pdf (13.2 MB) - Core 90-day deconstruction journal with complete Threshold Framework.
  4. 03_The_Belief-by-Belief_Guide.pdf (4.5 MB) - The step-by-step cognitive separation and belief audit manual.
  5. 04_The_Community-Creation_Guide.pdf (2.4 MB) - Strategies for navigating social friction, boundaries, and rebuilding community.
  6. 05_The_Secular-Ceremony_Templates.pdf (1.9 MB) - A collection of meaningful secular ceremonies and transition templates.
  7. 06_Grounding_Cards.pdf (2.8 MB) - Printable cognitive grounding cards for moments of anxiety or guilt.
  8. 07_Sales_Page_Copy_Kit.pdf (1.5 MB) - Complete copy deck and framing documentation for the Threshold framework.
  9. 08_Disclaimers_and_Care_Notice.pdf (0.8 MB) - Ethical care guidelines, self-reflection safety practices, and clinical disclaimers.
  10. README.txt (12 KB) - Comprehensive orientation guide and package file index.
  11. html-source/00_start_here.html (140 KB) - Editable HTML source file for the Start Here Quick-Start Guide.
  12. html-source/01_starter_journal.html (180 KB) - Editable HTML source file for the Starter Journal.
  13. html-source/02_90day_journal.html (420 KB) - Editable HTML source file for the 90-Day Deconstruction Journal.
  14. html-source/03_belief_guide.html (260 KB) - Editable HTML source file for the Belief-by-Belief Guide.
  15. html-source/04_community_guide.html (210 KB) - Editable HTML source file for the Community-Creation Guide.
  16. html-source/05_ceremony_templates.html (190 KB) - Editable HTML source file for the Ceremony Templates.
  17. html-source/06_grounding_cards.html (150 KB) - Editable HTML source file for Grounding Cards.
  18. html-source/07_sales_copy.html (110 KB) - Editable HTML source file for Sales Copy.
  19. html-source/08_care_notice.html (90 KB) - Editable HTML source file for Care Notice.

LICENSING & USAGE:
This toolkit is protected by copyright and licensed under the bootey Single-Seat Lifetime Commercial License.
You may use, adapt, and implement all worksheets, spreadsheets, and guides for personal and business use.
Redistribution, reselling, or public uploading of raw files is prohibited.

SUPPORT & POLAR CHECKOUT FULFILLMENT:
For inquiries or licensing questions: support@bootey.com
https://bootey.com
