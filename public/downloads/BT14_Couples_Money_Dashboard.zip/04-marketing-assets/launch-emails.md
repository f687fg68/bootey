# 04-marketing-assets/launch-emails.md
Toolkit: BT — 14 - Couples Money Dashboard
Asset: Announcement sequence for couples financial workshops.

============================================================
Official template and operational content ready for deployment.
