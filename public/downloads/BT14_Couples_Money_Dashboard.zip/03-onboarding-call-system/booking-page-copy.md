# 03-onboarding-call-system/booking-page-copy.md
Toolkit: BT — 14 - Couples Money Dashboard
Asset: Financial coach onboarding page copy.

============================================================
Official template and operational content ready for deployment.
