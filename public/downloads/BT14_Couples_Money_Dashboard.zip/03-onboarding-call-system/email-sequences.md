# 03-onboarding-call-system/email-sequences.md
Toolkit: BT — 14 - Couples Money Dashboard
Asset: Partner reminder and check-in email templates.

============================================================
Official template and operational content ready for deployment.
