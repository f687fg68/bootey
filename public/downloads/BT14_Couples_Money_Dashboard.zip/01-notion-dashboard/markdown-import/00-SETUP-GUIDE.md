# 01-notion-dashboard/markdown-import/00-SETUP-GUIDE.md
Toolkit: BT — 14 - Couples Money Dashboard
Asset: Step-by-step Notion dashboard setup guide.

============================================================
Official template and operational content ready for deployment.
