# 01-notion-dashboard/markdown-import/03-sunday-review-ritual.md
Toolkit: BT — 14 - Couples Money Dashboard
Asset: 5-minute Sunday standing agenda for zero-friction money dates.

============================================================
Official template and operational content ready for deployment.
