# 01-notion-dashboard/markdown-import/05-money-date-template.md
Toolkit: BT — 14 - Couples Money Dashboard
Asset: Guided conversational templates for monthly reviews.

============================================================
Official template and operational content ready for deployment.
