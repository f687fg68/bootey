======================================================================
bootey(R) DIGITAL TOOLKIT ARCHIVE
Product Code: BT — 14
Title: Couples Money Dashboard
Subtitle: Joint financial planner · XLSX
Price: $19.99 USD
Archive: BT14_Couples_Money_Dashboard.zip
Generated for: Verified Customer
======================================================================

PRODUCT SUMMARY:
For couples who fight about money or who never talk about it at all. A Notion and spreadsheet dashboard for two. 5 minutes a week. Both partners on the same page without micromanaging line items.

TABLE OF CONTENTS / MODULES:
  [1] 01 / The 5-Minute Sunday Financial Standup
  [2] 02 / The "Yours, Mine, Ours" Three-Account System
  [3] 03 / Automated Proportional Contribution Calculators
  [4] 04 / Financial Conflict De-escalation Scripts

INCLUDED ASSET MANIFEST (17 files):
  1. README.md (18 KB) - Welcome & 5-minute setup orientation.
  2. 01-notion-dashboard/markdown-import/00-SETUP-GUIDE.md (45 KB) - Step-by-step Notion dashboard setup guide.
  3. 01-notion-dashboard/markdown-import/01-main-dashboard.md (62 KB) - Central couples financial command center view.
  4. 01-notion-dashboard/markdown-import/02-income-expense-tracker.md (54 KB) - Proportional income & shared bill allocation.
  5. 01-notion-dashboard/markdown-import/03-sunday-review-ritual.md (38 KB) - 5-minute Sunday standing agenda for zero-friction money dates.
  6. 01-notion-dashboard/markdown-import/04-net-worth-tracker.md (42 KB) - Joint asset and retirement milestone tracker.
  7. 01-notion-dashboard/markdown-import/05-money-date-template.md (35 KB) - Guided conversational templates for monthly reviews.
  8. 01-notion-dashboard/markdown-import/06-savings-goals-tracker.md (48 KB) - Home, vacation, and family sinking fund goals.
  9. 01-notion-dashboard/html-preview/dashboard-preview.html (120 KB) - Interactive local visual preview of the dashboard.
  10. 02-video-course/90-min-video-course.pdf (8.4 MB) - Slides and video lecture transcript notes.
  11. 03-onboarding-call-system/booking-page-copy.md (28 KB) - Financial coach onboarding page copy.
  12. 03-onboarding-call-system/call-sop.pdf (2.1 MB) - Standard operating procedure for partner mediation.
  13. 03-onboarding-call-system/email-sequences.md (34 KB) - Partner reminder and check-in email templates.
  14. 03-onboarding-call-system/intake-form.md (22 KB) - Confidential values and spending style questionnaire.
  15. 04-marketing-assets/launch-emails.md (38 KB) - Announcement sequence for couples financial workshops.
  16. 04-marketing-assets/pricing-page.md (25 KB) - Pricing tiers: Template only vs coached edition.
  17. 04-marketing-assets/sales-page.pdf (4.5 MB) - Full print-ready sales page copy and objections breakdown.

LICENSING & USAGE:
This toolkit is protected by copyright and licensed under the bootey Single-Seat Lifetime Commercial License.
You may use, adapt, and implement all worksheets, spreadsheets, and guides for personal and business use.
Redistribution, reselling, or public uploading of raw files is prohibited.

SUPPORT & POLAR CHECKOUT FULFILLMENT:
For inquiries or licensing questions: support@bootey.com
https://bootey.com
