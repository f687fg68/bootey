======================================================================
bootey(R) DIGITAL TOOLKIT ARCHIVE
Product Code: BT — 18
Title: The Brag Document
Subtitle: Career wins tracker · XLSX, PDF
Price: $14.99 USD
Archive: BT18_The_Brag_Document.zip
Generated for: Verified Customer
======================================================================

PRODUCT SUMMARY:
Evidence, not vibes. A 4-step framework (Capture, Translate, Assemble, Price) to log your work wins all year long so performance reviews, promo discussions, and salary negotiations write themselves.

TABLE OF CONTENTS / MODULES:
  [1] 01 / Step 1: Capture (Five Minutes Every Friday)
  [2] 02 / Step 2: Translate (Turning Tasks into Business Impact Statements)
  [3] 03 / Step 3: Assemble (The One-Page Annual Review Dossier)
  [4] 04 / Step 4: Price (Tying Achievements to Salary Increases)

INCLUDED ASSET MANIFEST (11 files):
  1. 01-Win-Log.xlsx (3.6 MB) - Weekly impact log and engineering/product accomplishment recorder.
  2. 02-Impact-Translator.xlsx (2.8 MB) - Technical work to business metrics ($ revenue, cost savings, latency) translation matrix.
  3. 03-Weekly-Capture.xlsx (2.4 MB) - 5-minute Friday standup accomplishment capture template.
  4. 04-Review-Packet-Builder.xlsx (4.2 MB) - Automated self-review generator for semi-annual performance cycles.
  5. 05-Peer-Feedback-Tracker.xlsx (2.1 MB) - Praise bank, Slack shoutout archive, and stakeholder testimonial repository.
  6. 06-Salary-Evidence-File.xlsx (3.1 MB) - Comp negotiation dossier, market compensation comparisons, and level-up evidence docket.
  7. 07-Instructions-Checklists.xlsx (1.9 MB) - Promotion review readiness checklist and career ladder leveling rubric.
  8. START-HERE.pdf (3.8 MB) - Promotion packet assembly manual and performance review strategic playbook.
  9. LISTING-COPY.txt (24 KB) - Complete promotion tactics and performance talking points.
  10. LICENSE.txt (8 KB) - Single-seat lifetime commercial license agreement.
  11. README.txt (16 KB) - Welcome guide and career progression framework orientation.

LICENSING & USAGE:
This toolkit is protected by copyright and licensed under the bootey Single-Seat Lifetime Commercial License.
You may use, adapt, and implement all worksheets, spreadsheets, and guides for personal and business use.
Redistribution, reselling, or public uploading of raw files is prohibited.

SUPPORT & POLAR CHECKOUT FULFILLMENT:
For inquiries or licensing questions: support@bootey.com
https://bootey.com
