======================================================================
bootey(R) DIGITAL TOOLKIT ARCHIVE
Product Code: BT — 19
Title: Therapist Carousel Pack
Subtitle: Social media content kit · Templates
Price: $29.99 USD
Archive: BT19_Therapist_Carousel_Pack.zip
Generated for: Verified Customer
======================================================================

PRODUCT SUMMARY:
Professionally written, ethically sound psychoeducation social media templates designed specifically for licensed therapists, counselors, and mental health coaches growing a private caseload.

TABLE OF CONTENTS / MODULES:
  [1] 01 / Ethical Disclaimers & Non-Clinical Engagement Boundaries
  [2] 02 / 50 High-Saves Psychoeducational Carousel Wireframes
  [3] 03 / Hook Formulas for Anxiety, Trauma, and Relationship Topics
  [4] 04 / Converting Profile Visits to Consultation Bookings

INCLUDED ASSET MANIFEST (3 files):
  1. 50_Therapist_Carousel_Templates.pdf (22.8 MB) - Visual layout guide and copy paste slide text scripts.
  2. Canva_Figma_Editable_Source_Links.pdf (15.5 MB) - Direct 1-click links to editable Canva and Figma designs.
  3. License_Perpetual.txt (12 KB) - Single-seat lifetime perpetual license.

LICENSING & USAGE:
This toolkit is protected by copyright and licensed under the bootey Single-Seat Lifetime Commercial License.
You may use, adapt, and implement all worksheets, spreadsheets, and guides for personal and business use.
Redistribution, reselling, or public uploading of raw files is prohibited.

SUPPORT & POLAR CHECKOUT FULFILLMENT:
For inquiries or licensing questions: support@bootey.com
https://bootey.com
