======================================================================
bootey(R) DIGITAL TOOLKIT ARCHIVE
Product Code: BT — 28
Title: Wedding Invitation Mega Bundle
Subtitle: Complete wedding stationery · Templates
Price: $39.99 USD
Archive: BT28_Wedding_Invitation_Mega_Bundle.zip
Generated for: Verified Customer
======================================================================

PRODUCT SUMMARY:
The Designer Collection. Includes Save the Dates, Invitations, Details cards, RSVPs, Menus, Place cards, and Signs. Five pages of orientation before you begin so you avoid the five mistakes that cost couples hundreds.

TABLE OF CONTENTS / MODULES:
  [1] 01 / Orientation: How to Avoid the 5 Costly DIY Printing Mistakes
  [2] 02 / The Invitation Suite: Save the Date, Main Invite, & RSVP
  [3] 03 / Day-Of Stationery: Menus, Place Cards, Programs, & Welcome Signs
  [4] 04 / Commercial Print Bleed, CMYK Calibration, & Paper Stock Guide

INCLUDED ASSET MANIFEST (4 files):
  1. How_To_Use_This_Bundle_Guide.pdf (12.4 MB) - Step-by-step buyer orientation & print specification handbook.
  2. The_Designer_Collection_Suite_Templates.pdf (22.8 MB) - 50+ stationery templates with direct editable design links.
  3. Print_Shop_Vendor_Discount_Codes.pdf (13.3 MB) - Curated paper stock guide and vendor discount access.
  4. License_Perpetual.txt (12 KB) - Single-seat lifetime perpetual license.

LICENSING & USAGE:
This toolkit is protected by copyright and licensed under the bootey Single-Seat Lifetime Commercial License.
You may use, adapt, and implement all worksheets, spreadsheets, and guides for personal and business use.
Redistribution, reselling, or public uploading of raw files is prohibited.

SUPPORT & POLAR CHECKOUT FULFILLMENT:
For inquiries or licensing questions: support@bootey.com
https://bootey.com
