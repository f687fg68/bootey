# 07_BRAND_ASSETS/brand_guide.md
Toolkit: BT — 22 - ADHD Dashboard Kit
Asset: Minimalist low-stimulation palette & visual tokens.

============================================================
Official template and operational content ready for deployment.
