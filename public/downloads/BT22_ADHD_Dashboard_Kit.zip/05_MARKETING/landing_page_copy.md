# 05_MARKETING/landing_page_copy.md
Toolkit: BT — 22 - ADHD Dashboard Kit
Asset: High-converting sales copy for neurodivergent adults.

============================================================
Official template and operational content ready for deployment.
