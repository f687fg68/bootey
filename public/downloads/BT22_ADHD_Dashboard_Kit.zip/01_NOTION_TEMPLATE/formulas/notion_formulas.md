# 01_NOTION_TEMPLATE/formulas/notion_formulas.md
Toolkit: BT — 22 - ADHD Dashboard Kit
Asset: Automated urgency and dopamine score formulas.

============================================================
Official template and operational content ready for deployment.
