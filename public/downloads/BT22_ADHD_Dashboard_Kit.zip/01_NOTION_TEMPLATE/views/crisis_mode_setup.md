# 01_NOTION_TEMPLATE/views/crisis_mode_setup.md
Toolkit: BT — 22 - ADHD Dashboard Kit
Asset: 1-click crisis view for acute overwhelm days.

============================================================
Official template and operational content ready for deployment.
