# EDITABLE-TEMPLATES/ALL-25-TEMPLATES.md
Toolkit: BT — 21 - ADHD Parent-Teacher Communication Pack
Asset: Single file containing all 25 copy-paste email templates.

============================================================
Official template and operational content ready for deployment.
