======================================================================
bootey(R) DIGITAL TOOLKIT ARCHIVE
Product Code: BT — 23
Title: IVF Journey Tracker
Subtitle: Fertility treatment companion · PDF
Price: $39.99 USD
Archive: BT23_IVF_Journey_Tracker.zip
Generated for: Verified Customer
======================================================================

PRODUCT SUMMARY:
The clinical numbers are tracked elsewhere. This section holds what can't be measured — the heart of the journey, the grief, the hope, and the becoming. Complete with injection protocol logs and ultrasound tracking.

TABLE OF CONTENTS / MODULES:
  [1] 01 / Cycle Protocol & Medication Dosage Timetables
  [2] 02 / Follicle Growth & Ultrasound Biomarker Charts
  [3] 03 / Embryo Grading & Genetic Testing Logs
  [4] 04 / Cycle Reflection Journal: Grounding for the Two-Week Wait

INCLUDED ASSET MANIFEST (9 files):
  1. IVF_Journey_Tracker_Master_130_pages.pdf (14.2 MB) - Master 130-page clinical and emotional IVF cycle companion and fertility binder.
  2. section_1_injection_tracker.pdf (2.8 MB) - Daily gonadotropin, trigger shot, and medication dosage and site rotation tracker.
  3. section_2_follicle_growth.pdf (3.1 MB) - Ultrasound monitoring, follicle size measurement, and estradiol level charting.
  4. section_3_embryo_transfer.pdf (2.6 MB) - Fresh/frozen transfer prep, progesterone protocol, and embryo grading reference log.
  5. section_4_beta_hcg.pdf (2.2 MB) - Two-week wait symptom tracker, blood beta hCG doubling time calculator.
  6. section_5_reflection_journal.pdf (3.4 MB) - Decompression prompts for grief, hope, body trust, and emotional stamina.
  7. section_6_financial_tracker.pdf (2.1 MB) - Out-of-pocket cycle costs, medication billing, prior authorizations, and grant ledger.
  8. section_7_partner_boundaries.pdf (1.9 MB) - Couple boundary setting and family update boundary scripts to stop probing questions.
  9. README.txt (12 KB) - Quick-start clinic binder setup orientation and medication checklist.

LICENSING & USAGE:
This toolkit is protected by copyright and licensed under the bootey Single-Seat Lifetime Commercial License.
You may use, adapt, and implement all worksheets, spreadsheets, and guides for personal and business use.
Redistribution, reselling, or public uploading of raw files is prohibited.

SUPPORT & POLAR CHECKOUT FULFILLMENT:
For inquiries or licensing questions: support@bootey.com
https://bootey.com
