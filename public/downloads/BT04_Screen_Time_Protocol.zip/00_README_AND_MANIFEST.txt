======================================================================
bootey(R) DIGITAL TOOLKIT ARCHIVE
Product Code: BT — 04
Title: Screen Time Protocol
Subtitle: Family digital wellness · PDF bundle
Price: $19.99 USD
Archive: BT04_Screen_Time_Protocol.zip
Generated for: Verified Customer
======================================================================

PRODUCT SUMMARY:
A step-by-step, week-by-week roadmap that calmly walks your child from 4–8 hours of daily screen time down to a steady 90 minutes a day — with scheduled targets, replacement activities, and word-for-word meltdown scripts, so you never have to improvise under pressure again.

TABLE OF CONTENTS / MODULES:
  [1] 01 / Week 1: Passive Baseline & Friction Engineering
  [2] 02 / Week 2: First Cut Target & Boredom Resilience
  [3] 03 / Week 3: Replacement Activity Architecture
  [4] 04 / Week 4: The 90-Minute Sustainable End State
  [5] 05 / Word-for-Word Tantrum & Negotiation Scripts

INCLUDED ASSET MANIFEST (11 files):
  1. 01-The-30-Day-Protocol.pdf (8.5 MB) - Full 30-day dopamine reset and progressive screen detox protocol.
  2. 02-Replacement-Activity-Library.pdf (5.4 MB) - 100+ screen-free high-dopamine substitute activities for children and teens.
  3. 03-Meltdown-Script-Pack.pdf (3.6 MB) - De-escalation scripts and boundary reinforcement language during tantrums.
  4. 04-Weekly-Check-In-Templates.pdf (2.8 MB) - Family progress check-in sheets and weekly screen audit worksheets.
  5. 05-Family-Meal-Time-Pack.pdf (2.2 MB) - Screen-free dinner conversation starters and evening family rituals.
  6. source-files/01-protocol.html (340 KB) - Editable source file for the 30-day protocol manual.
  7. source-files/02-activity-library.html (420 KB) - Editable source file for the replacement activity library.
  8. source-files/03-meltdown-scripts.html (280 KB) - Editable source file for meltdown de-escalation scripts.
  9. source-files/04-weekly-checkins.html (190 KB) - Editable source file for weekly family check-ins.
  10. source-files/05-meal-time-pack.html (210 KB) - Editable source file for meal-time conversation pack.
  11. README.txt (15 KB) - Welcome guide, household rules checklist, and implementation plan.

LICENSING & USAGE:
This toolkit is protected by copyright and licensed under the bootey Single-Seat Lifetime Commercial License.
You may use, adapt, and implement all worksheets, spreadsheets, and guides for personal and business use.
Redistribution, reselling, or public uploading of raw files is prohibited.

SUPPORT & POLAR CHECKOUT FULFILLMENT:
For inquiries or licensing questions: support@bootey.com
https://bootey.com
